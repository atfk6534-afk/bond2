import 'package:flutter_test/flutter_test.dart';

import 'package:bond2/core/database/database.dart';
import 'package:bond2/features/grades/grades_repository.dart';
import 'package:bond2/features/students/students_repository.dart';

void main() {
  late AppDatabase db;
  late StudentsRepository studentsRepo;
  late GradesRepository gradesRepo;

  setUp(() {
    db = openTestDatabase();
    studentsRepo = StudentsRepository(db);
    gradesRepo = GradesRepository(db);
  });

  tearDown(() async {
    await db.close();
  });

  group('Grade validation (rule #70)', () {
    test('rejects a zero or negative maxScore', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      expect(
        () => gradesRepo.addGrade(
          studentId: studentId, examName: 'امتحان', date: DateTime.now(), score: 5, maxScore: 0,
        ),
        throwsA(isA<ArgumentError>()),
      );
      expect(
        () => gradesRepo.addGrade(
          studentId: studentId, examName: 'امتحان', date: DateTime.now(), score: 5, maxScore: -10,
        ),
        throwsA(isA<ArgumentError>()),
      );
    });

    test('rejects a negative score', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      expect(
        () => gradesRepo.addGrade(
          studentId: studentId, examName: 'امتحان', date: DateTime.now(), score: -1, maxScore: 100,
        ),
        throwsA(isA<ArgumentError>()),
      );
    });

    test('rejects a score exceeding maxScore unless bonus points are explicitly allowed', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      expect(
        () => gradesRepo.addGrade(
          studentId: studentId, examName: 'امتحان', date: DateTime.now(), score: 110, maxScore: 100,
        ),
        throwsA(isA<ArgumentError>()),
      );
      // With bonus points explicitly allowed, it succeeds.
      final id = await gradesRepo.addGrade(
        studentId: studentId, examName: 'امتحان مع مكافأة', date: DateTime.now(),
        score: 105, maxScore: 100, allowBonusPoints: true,
      );
      expect(id, isNotEmpty);
    });

    test('rejects an empty exam name', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      expect(
        () => gradesRepo.addGrade(
          studentId: studentId, examName: '   ', date: DateTime.now(), score: 50, maxScore: 100,
        ),
        throwsA(isA<ArgumentError>()),
      );
    });
  });

  group('Average percentage calculation (fix: check the calculations)', () {
    test('a single exam averages to its own percentage', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب واحد');
      await gradesRepo.addGrade(
        studentId: studentId, examName: 'امتحان', date: DateTime.now(), score: 8, maxScore: 10,
      );
      final summary = await gradesRepo.summaryFor(studentId);
      expect(summary.averagePercentage, 80.0);
    });

    test(
        'CRITICAL: averages PERCENTAGES across exams with different scales, '
        'never raw scores directly', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب مقاييس مختلفة');
      // Exam 1: 8/10 = 80%. Exam 2: 40/50 = 80%. Correct average = 80%.
      // A naive raw-score average ((8+40)/2 = 24) would be meaningless.
      await gradesRepo.addGrade(
        studentId: studentId, examName: 'كويز', date: DateTime.now(), score: 8, maxScore: 10,
      );
      await gradesRepo.addGrade(
        studentId: studentId, examName: 'امتحان شهري', date: DateTime.now(), score: 40, maxScore: 50,
      );

      final summary = await gradesRepo.summaryFor(studentId);
      expect(summary.count, 2);
      expect(summary.averagePercentage, 80.0);
    });

    test('correctly averages three exams with different percentages', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب ثلاثة امتحانات');
      // 100%, 50%, 0% -> average must be exactly 50%.
      await gradesRepo.addGrade(
        studentId: studentId, examName: 'امتحان 1', date: DateTime.now(), score: 100, maxScore: 100,
      );
      await gradesRepo.addGrade(
        studentId: studentId, examName: 'امتحان 2', date: DateTime.now(), score: 50, maxScore: 100,
      );
      await gradesRepo.addGrade(
        studentId: studentId, examName: 'امتحان 3', date: DateTime.now(), score: 0, maxScore: 100,
      );

      final summary = await gradesRepo.summaryFor(studentId);
      expect(summary.count, 3);
      expect(summary.averagePercentage, 50.0);
    });

    test('a student with no grades has a null average, never a misleading 0%', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب بدون درجات');
      final summary = await gradesRepo.summaryFor(studentId);
      expect(summary.count, 0);
      expect(summary.averagePercentage, isNull);
    });

    test('bonus-point exams (score > maxScore) contribute a percentage above 100%, '
        'correctly pulling the average up', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب مكافأة');
      await gradesRepo.addGrade(
        studentId: studentId, examName: 'عادي', date: DateTime.now(), score: 80, maxScore: 100,
      );
      await gradesRepo.addGrade(
        studentId: studentId, examName: 'مكافأة', date: DateTime.now(),
        score: 110, maxScore: 100, allowBonusPoints: true,
      );
      // (80% + 110%) / 2 = 95%.
      final summary = await gradesRepo.summaryFor(studentId);
      expect(summary.averagePercentage, 95.0);
    });
  });

  group('Grade management', () {
    test('deleteGrade removes the record and updates the average', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب حذف');
      final id1 = await gradesRepo.addGrade(
        studentId: studentId, examName: 'امتحان 1', date: DateTime.now(), score: 100, maxScore: 100,
      );
      await gradesRepo.addGrade(
        studentId: studentId, examName: 'امتحان 2', date: DateTime.now(), score: 0, maxScore: 100,
      );

      var summary = await gradesRepo.summaryFor(studentId);
      expect(summary.count, 2);
      expect(summary.averagePercentage, 50.0);

      await gradesRepo.deleteGrade(id1);

      summary = await gradesRepo.summaryFor(studentId);
      expect(summary.count, 1);
      expect(summary.averagePercentage, 0.0);
    });

    test('grades for one student never leak into another student\'s summary', () async {
      final s1 = await studentsRepo.addStudent(name: 'طالب أ');
      final s2 = await studentsRepo.addStudent(name: 'طالب ب');
      await gradesRepo.addGrade(studentId: s1, examName: 'امتحان', date: DateTime.now(), score: 100, maxScore: 100);
      await gradesRepo.addGrade(studentId: s2, examName: 'امتحان', date: DateTime.now(), score: 0, maxScore: 100);

      final summary1 = await gradesRepo.summaryFor(s1);
      final summary2 = await gradesRepo.summaryFor(s2);
      expect(summary1.averagePercentage, 100.0);
      expect(summary2.averagePercentage, 0.0);
    });
  });
}
