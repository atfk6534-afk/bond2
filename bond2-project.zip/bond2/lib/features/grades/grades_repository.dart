import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/database/database.dart';
import '../../core/database/database_provider.dart';
import '../../core/utils/id_generator.dart';

/// A student's grade summary across a set of exams.
///
/// IMPORTANT ON THE AVERAGE CALCULATION: exams rarely share the same
/// [ExamGrade.maxScore] (a quiz might be out of 10, a final out of 100).
/// Averaging raw scores directly (e.g. (8 + 40) / 2 = 24) would be
/// meaningless across mixed scales. This class always works in
/// PERCENTAGE space per exam first (score / maxScore * 100), then
/// averages those percentages - so a student who got 8/10 on one exam
/// and 40/50 on another correctly averages to 80%, not a nonsensical
/// raw-score blend.
class StudentGradeSummary {
  final List<ExamGrade> grades;
  const StudentGradeSummary(this.grades);

  int get count => grades.length;

  /// Average percentage across all exams, or null if there are none yet
  /// (never divide by zero, and never silently report "0%" for a
  /// student who simply has no grades recorded).
  double? get averagePercentage {
    if (grades.isEmpty) return null;
    final validGrades = grades.where((g) => g.maxScore > 0).toList();
    if (validGrades.isEmpty) return null;
    final totalPercentage = validGrades.fold<double>(
      0,
      (sum, g) => sum + (g.score / g.maxScore * 100),
    );
    return totalPercentage / validGrades.length;
  }
}

class GradesRepository {
  final AppDatabase db;
  GradesRepository(this.db);

  Stream<List<ExamGrade>> watchForStudent(String studentId) {
    return (db.select(db.examGrades)
          ..where((t) => t.studentId.equals(studentId))
          ..orderBy([(t) => OrderingTerm.desc(t.date)]))
        .watch();
  }

  Future<StudentGradeSummary> summaryFor(String studentId) async {
    final grades = await (db.select(db.examGrades)
          ..where((t) => t.studentId.equals(studentId)))
        .get();
    return StudentGradeSummary(grades);
  }

  /// Records an exam grade. [score] must be >= 0 and [maxScore] must be
  /// > 0 (a zero-or-negative maxScore would make the percentage
  /// calculation meaningless/undefined - rule #70, validate before
  /// saving rather than storing bad data and discovering it later in a
  /// report). [score] may exceed [maxScore] only if [allowBonusPoints]
  /// is explicitly true (some teachers do give bonus points above the
  /// nominal maximum) - otherwise it is rejected, matching the same
  /// "reject invalid input outright" philosophy used for payments
  /// (rule #69's overpayment guard).
  Future<String> addGrade({
    required String studentId,
    String? subjectId,
    String? academicYearId,
    String? groupId,
    required String examName,
    required DateTime date,
    required double score,
    double maxScore = 100.0,
    String? notes,
    bool allowBonusPoints = false,
  }) async {
    if (maxScore <= 0) {
      throw ArgumentError('الدرجة النهائية يجب أن تكون أكبر من صفر');
    }
    if (score < 0) {
      throw ArgumentError('الدرجة لا يمكن أن تكون سالبة');
    }
    if (score > maxScore && !allowBonusPoints) {
      throw ArgumentError('الدرجة أكبر من الدرجة النهائية للامتحان');
    }
    if (examName.trim().isEmpty) {
      throw ArgumentError('اسم الامتحان مطلوب');
    }

    final id = IdGenerator.newId();
    await db.into(db.examGrades).insert(ExamGradesCompanion.insert(
          id: id,
          studentId: studentId,
          subjectId: Value(subjectId),
          academicYearId: Value(academicYearId),
          groupId: Value(groupId),
          examName: examName.trim(),
          date: Value(date),
          score: score,
          maxScore: Value(maxScore),
          notes: Value(notes),
        ));
    return id;
  }

  Future<void> deleteGrade(String gradeId) async {
    await (db.delete(db.examGrades)..where((t) => t.id.equals(gradeId))).go();
  }

  Future<void> updateGrade(ExamGrade grade) => db.update(db.examGrades).replace(grade);
}

final gradesRepositoryProvider = Provider<GradesRepository>((ref) {
  return GradesRepository(ref.watch(databaseProvider));
});

final studentGradesProvider = StreamProvider.family<List<ExamGrade>, String>((ref, studentId) {
  return ref.watch(gradesRepositoryProvider).watchForStudent(studentId);
});

final studentGradeSummaryProvider =
    FutureProvider.family<StudentGradeSummary, String>((ref, studentId) {
  return ref.watch(gradesRepositoryProvider).summaryFor(studentId);
});
